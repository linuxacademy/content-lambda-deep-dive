import json
import datetime
import time
import boto3


## Importing ec2 boto3 resource.
# ec2 = boto3.resource('ec2')
ec2 = boto3.client('ec2')

print('     !Running your function!     ')

def lambda_handler(event, context):
    #print(event)

    ## Getting the Instance ID of the instance that is shutting down.
    instanceID = event['detail']['instance-id']

    # ## Setting the instance ID for later.
    # instance = ec2.Instance(instanceID)

    instances = ec2.describe_instances(
        InstanceIds=[
            instanceID,
        ]
    )

    for reservation in instances['Reservations']:
        for instance in reservation['Instances']:
            for device in instance['BlockDeviceMappings']:
                ebs = device['Ebs']['VolumeId']
                print("We are going to snapshot the volume %s" % ebs)

                ec2.create_snapshot(
                    Description='From instance: %s' % instanceID,
                    VolumeId=ebs,
                )
